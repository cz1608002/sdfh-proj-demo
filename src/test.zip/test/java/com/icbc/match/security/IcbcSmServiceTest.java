package com.icbc.match.security;

import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class IcbcSmServiceTest {

    @Autowired
    private IcbcSmService icbcSmService;

    @Test
    public void test() {


        Gson gson = new Gson();
        Map map = new HashMap();
//        map.put("name", "123");
        map.put("mediumId", "2JUQTCiA2WOPU8kFC/DxTlHoa7hhmruQIrcTOFwnzp0\u003d");
        map.put("secretKey", "GXatjy2XozyKbCec8WaeYcuuuGsNRjaDlcYUfux4uQf9XuuGHl/c7oMy91I1Zb0/tm+nW88DBCvEm149Hc/or9A/W24vk0KwEJSTqrSLvt8v4emT56TLGJIGgxp99KMMxzK+2cN33Ub7uAMxZSavFw\u003d\u003d");
//        map = icbcSmService.encrypt(map);

        map = icbcSmService.decrypt(map);

        log.info(gson.toJson(map));
    }


}
