package com.icbc.match.api.service.icbc;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import com.icbc.match.entity.SettlementAccountBranchOpen;
import com.icbc.match.security.IcbcSmService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class SettlementAccountBranchOpenV2ServiceTest {

    @Autowired
    private SettlementAccountBranchOpenV2Service settlementAccountBranchOpenV2Service;

    @Autowired
    private IcbcSmService icbcSmService;

    @Test
    public void test() {
        //本地图片转base64编码

        Gson gson = new Gson();

        Map<String, String> map = new HashMap();
        map.put("certNo", "125458196608202109");
        map.put("custName", "票奏渍");
        map.put("bindMedium", "6222000200127516730");
        map.put("mobile", "18810743881");
        map = icbcSmService.encrypt(map);

        System.out.println(gson.toJson(icbcSmService.encrypt(map)));
        String romdom = "FHJS025" + IdUtil.simpleUUID().substring(0, 6);
        log.info("@@:FHJS025::" + romdom);

        String cisNo = IdUtil.simpleUUID();//合作方客户号

        SettlementAccountBranchOpen settlementAccountBranchOpen = new SettlementAccountBranchOpen();
        settlementAccountBranchOpen.setCorpNo(ApiConstants.CORP_NO);
        settlementAccountBranchOpen.setTrxAccDate(ApiConstants.ACC_DATE);
        settlementAccountBranchOpen.setTrxAccTime(DateUtil.formatTime(DateUtil.date()));
        settlementAccountBranchOpen.setCorpDate(ApiConstants.ACC_DATE);
        settlementAccountBranchOpen.setCorpSerno(romdom);
        settlementAccountBranchOpen.setOutServiceCode("openaccount");
        settlementAccountBranchOpen.setCorpCisNo(cisNo);
        settlementAccountBranchOpen.setCorpMediumId(romdom);
        settlementAccountBranchOpen.setBindMedium(map.get("bindMedium"));
        settlementAccountBranchOpen.setCertType(0);
        settlementAccountBranchOpen.setCertNo(map.get("certNo"));
        settlementAccountBranchOpen.setCustName(map.get("custName"));
        settlementAccountBranchOpen.setMobileNo(map.get("mobile"));
        settlementAccountBranchOpen.setGender(2);
        settlementAccountBranchOpen.setOccupation(3);
        settlementAccountBranchOpen.setForeverFlag(0);
        settlementAccountBranchOpen.setSignDate("2018-12-01");  //签发日期
        settlementAccountBranchOpen.setValidityPeriod("2033-12-11");  //失效日期
        settlementAccountBranchOpen.setNationality(156);
        settlementAccountBranchOpen.setTaxDeclarationFlag(1);
        settlementAccountBranchOpen.setSecretKey(map.get("secretKey"));
        settlementAccountBranchOpen.setAddress("济南市中区经四路");

        log.info("上送报文：{}", settlementAccountBranchOpen);
        Map result = settlementAccountBranchOpenV2Service.execute(settlementAccountBranchOpen);

        log.info("返回报文：{}", gson.toJson(result));

        Assert.assertEquals("0", result.get("return_code").toString());
        log.info("result.get(\"return_code\").toString(){}", result.get("return_code").toString());
    }
}
