package com.icbc.match.api.service.icbc;

import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;

import com.icbc.match.YkgyjApplication;
import com.icbc.match.api.service.icbc.SettlementAccountBranchQueryApplyV1Service;
import com.icbc.match.config.ApiConstants;
import com.icbc.match.entity.SettlementAccountBranchQueryApply;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class SettlementAccountBranchQueryApplyV1ServiceTest {

    @Autowired
    private SettlementAccountBranchQueryApplyV1Service settlementAccountBranchQueryApplyV1Service;

    @Test
    public void SettlementAccountBranchQueryApplyV1ServiceTest() {

        Gson gson = new Gson();

        String serno = "FHJS025" + IdUtil.simpleUUID().substring(0, 6);
        log.info("@@FHJS025:" + serno);


        SettlementAccountBranchQueryApply settlementAccountBranchQueryApply = new SettlementAccountBranchQueryApply();
        settlementAccountBranchQueryApply.setCorpNo(ApiConstants.CORP_NO);
        settlementAccountBranchQueryApply.setCorpSerno(serno);
        settlementAccountBranchQueryApply.setOutServiceCode("queryapply");
        settlementAccountBranchQueryApply.setOriCorpSerno("FHJS02509cbaa");
        Map result = settlementAccountBranchQueryApplyV1Service.settlementAccountBranchQueryApply(settlementAccountBranchQueryApply);


        log.info(gson.toJson(result));


    }

}
