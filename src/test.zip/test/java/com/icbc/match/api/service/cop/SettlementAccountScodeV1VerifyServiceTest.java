package com.icbc.match.api.service.cop;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.api.request.SettlementAccountSCodeVerifyRequestV1;
import com.icbc.api.response.SettlementAccountSCodeVerifyResponseV1;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class SettlementAccountScodeV1VerifyServiceTest {

    @Autowired
    private SettlementAccountScodeV1VerifyService settlementAccountScodeV1VerifyService;

    @Test
    public void test() {

        String serNo = "FHJS025" + IdUtil.simpleUUID().substring(0, 9);
        log.info("serNo:{}", serNo);
        SettlementAccountSCodeVerifyRequestV1.SettlementAccountSCodeVerifyRequestV1Biz bizContent = new SettlementAccountSCodeVerifyRequestV1.SettlementAccountSCodeVerifyRequestV1Biz();
        Gson gson = new Gson();
        bizContent.setCorpNo(ApiConstants.CORP_NO);
        bizContent.setTrxAccDate("2020-12-31");
        bizContent.setTrxAccTime(DateUtil.formatTime(DateUtil.date()));
        bizContent.setCorpDate("2020-12-31");
        bizContent.setCorpSerno(serNo);
        bizContent.setOutServiceCode("scodeverify");
        bizContent.setCorpSernoOriginal("FHJS025a1b622473");
        bizContent.setSmsSendNo("146915");
        bizContent.setSmsSCode("955888");
        SettlementAccountSCodeVerifyResponseV1 response = settlementAccountScodeV1VerifyService.execute(bizContent);

        log.info(gson.toJson(response));

    }
}
