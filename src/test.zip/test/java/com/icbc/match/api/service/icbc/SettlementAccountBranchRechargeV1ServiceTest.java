package com.icbc.match.api.service.icbc;

import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import com.icbc.match.entity.SettlementAccountBranchRecharge;
import com.icbc.match.security.IcbcSmService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class SettlementAccountBranchRechargeV1ServiceTest {

    @Autowired
    private SettlementAccountBranchRechargeV1Service settlementAccountBranchRechargeV1Service;

    @Autowired
    private IcbcSmService icbcSmService;

    @Test
    public void test() {

        Gson gson = new Gson();

        String romdom = "FHJS025" + IdUtil.simpleUUID().substring(0, 6);
        System.out.println("romdom:" + romdom);

        Map<String, String> map = new HashMap();
        map.put("mediumId", "6214760200611509271");
        map.put("bindMedium", "6222000200127516730");
        map = icbcSmService.encrypt(map);


        SettlementAccountBranchRecharge settlementAccountBranchRecharge = new SettlementAccountBranchRecharge();
        settlementAccountBranchRecharge.setCorpNo(ApiConstants.CORP_NO);
        settlementAccountBranchRecharge.setTrxAccDate(ApiConstants.ACC_DATE);
        settlementAccountBranchRecharge.setTrxAccTime("12:12:30");
        settlementAccountBranchRecharge.setCorpDate(ApiConstants.ACC_DATE);
        settlementAccountBranchRecharge.setCorpSerno(romdom);
        settlementAccountBranchRecharge.setOutServiceCode("recharge");
        settlementAccountBranchRecharge.setMediumId(map.get("mediumId"));
        settlementAccountBranchRecharge.setBindMedium(map.get("bindMedium"));
        settlementAccountBranchRecharge.setCcy(001);
        settlementAccountBranchRecharge.setCashExFlag(0);
        settlementAccountBranchRecharge.setAmount("100");
        settlementAccountBranchRecharge.setSummary("充值");
        settlementAccountBranchRecharge.setSecretKey(map.get("secretKey"));
        Map result = settlementAccountBranchRechargeV1Service.execute(settlementAccountBranchRecharge);

        log.info(gson.toJson(result));


    }
}
