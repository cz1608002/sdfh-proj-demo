package com.icbc.match.api.service.cop;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.api.request.DepositFixedTotalqueryRequestV1;
import com.icbc.api.response.DepositFixedTotalqueryResponseV1;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import com.icbc.match.security.IcbcSmService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class DepositFixedTotalqueryV1ServiceTest {

    @Autowired
    private DepositFixedTotalqueryV1Service depositFixedTotalqueryV1Service;

    @Autowired
    private IcbcSmService icbcSmService;

    @Test
    public void test() {
        Map<String, String> map = new HashMap();
        map.put("mediumId", "6214760200611510378");
        map = icbcSmService.encrypt(map);

        String serNo = "FHJS025" + IdUtil.simpleUUID().substring(0, 9);
        String cisNo = IdUtil.simpleUUID();//合作方客户号
        log.info("serNo:{},cisNo:{}", serNo, cisNo);

        Gson gson = new Gson();
        DepositFixedTotalqueryRequestV1.DepositFixedTotalqueryRequestV1Biz bizContent = new DepositFixedTotalqueryRequestV1.DepositFixedTotalqueryRequestV1Biz();
        bizContent.setCmExternalEventNo(serNo);
        bizContent.setCmAppId(ApiConstants.CORP_NO);
        bizContent.setCmWorkdate(ApiConstants.ACC_DATE);
        bizContent.setCmWorktime(DateUtil.formatTime(DateUtil.date()));
        bizContent.setCmOutServiceCode("fixedtotalquery");
        bizContent.setCmSecretKey(map.get("secretKey"));
        bizContent.setMediumNo(map.get("mediumId"));
        DepositFixedTotalqueryResponseV1 response = depositFixedTotalqueryV1Service.execute(bizContent);

        log.info(gson.toJson(response));

    }
}
