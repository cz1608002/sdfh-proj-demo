package com.icbc.match.api.service.cop;

import com.google.gson.Gson;
import com.icbc.api.request.CertPersonalProofProofcheckRequestV1;
import com.icbc.api.response.CertPersonalProofProofcheckResponseV1;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.utils.ImageToBasse64Util;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class CertPersonalProofProofcheckV1ServiceTest {

    @Autowired
    private CertPersonalProofProofcheckV1Service certPersonalProofProofcheckV1Service;

    @Test
    public void test() {

        String imageBase64 = ImageToBasse64Util.ImageToBase64ByLocal("E:\\images\\cert2.jpg");

        Gson gson = new Gson();

        CertPersonalProofProofcheckRequestV1.CertPersonalProofProofcheckRequestV1Biz bizContent = new CertPersonalProofProofcheckRequestV1.CertPersonalProofProofcheckRequestV1Biz();
        bizContent.setCaseId("2");
        bizContent.setChannel("2");
        bizContent.setImageFile(imageBase64);
        bizContent.setReqId("dqwdqw");


        CertPersonalProofProofcheckResponseV1 response = certPersonalProofProofcheckV1Service.execute(bizContent);

        log.info(gson.toJson(response));

    }
}
