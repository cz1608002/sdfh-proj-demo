package com.icbc.match.api.service.icbc;

import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import com.icbc.match.entity.SettlementAccountBranchQueryOpen;
import com.icbc.match.security.IcbcSmService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class SettlementAccountBranchQueryOpenV1ServiceTest {

    @Autowired
    private SettlementAccountBranchQueryOpenV1Service settlementAccountBranchQueryOpenV1Service;

    @Autowired
    private IcbcSmService icbcSmService;

    @Test
    public void personalProofcheckV1Test() {

        Gson gson = new Gson();

        String serno = "FHJS025" + IdUtil.simpleUUID().substring(0, 6);
        log.info("@@FHJS025:" + serno);
        SettlementAccountBranchQueryOpen settlementAccountBranchQueryOpen = new SettlementAccountBranchQueryOpen();
        settlementAccountBranchQueryOpen.setCorpNo(ApiConstants.CORP_NO);
        settlementAccountBranchQueryOpen.setOutServiceCode("queryopenbook");
        settlementAccountBranchQueryOpen.setOpenCorpSerno("FHJS025bfe52c");
        settlementAccountBranchQueryOpen.setCallType("API");

        Map result = settlementAccountBranchQueryOpenV1Service.execute(settlementAccountBranchQueryOpen);

        log.info("api返回报文：{}", gson.toJson(result));

        Map map = new HashMap();
        map.put("mediumId", result.get("medium_id"));
        map.put("secretKey", result.get("secret_key"));


        log.info("解密获得二类户卡号：{}", icbcSmService.decrypt(map));


    }
}
