package com.icbc.match.api.service.icbc;


import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.entity.BranchOrientedtransfer;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;


@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class BranchOrientedtransferServiceTest {


    @Autowired
    private BranchOrientedtransferService branchOrientedtransferService;

    @Test
    public void BranchOrientedtransferServiceTest() {

        Gson gson = new Gson();
        BranchOrientedtransfer branchOrientedtransfer = new BranchOrientedtransfer();
        branchOrientedtransfer.setCorpNo("corpInst1234");
        branchOrientedtransfer.setTrxAccDate("2017-03-15");
        branchOrientedtransfer.setTrxAccTime("13:30:01");
        branchOrientedtransfer.setCorpDate("2017-03-15");
        branchOrientedtransfer.setCorpSerno("ABC987654321");
        branchOrientedtransfer.setOutServiceCode("unbinding");
        branchOrientedtransfer.setMediumId("6214760200000022233");
        branchOrientedtransfer.setCcy("1");
        branchOrientedtransfer.setCashExFlag("0");
        branchOrientedtransfer.setAmount("300");
        branchOrientedtransfer.setOaccno("0200026009456784219");
        branchOrientedtransfer.setDrcrdirection("1");
        branchOrientedtransfer.setSummary("CS");
        branchOrientedtransfer.setRemarks("CS");
        branchOrientedtransfer.setNotifyAddr("");
        branchOrientedtransfer.setOmediumIdHash("");
        branchOrientedtransfer.setCertType("0");
        branchOrientedtransfer.setCorpNo("999999199009099991");
        branchOrientedtransfer.setCustName("九九九九九九九九九九九九九九");
        branchOrientedtransfer.setSecretKey("ASDQWEQDZCSDFAWWQDA");



        Map result = branchOrientedtransferService.branchOrientedtransfer(branchOrientedtransfer);

        log.info(gson.toJson(result));

        Assert.assertEquals("0", result.get("return_code").toString());


    }

}

