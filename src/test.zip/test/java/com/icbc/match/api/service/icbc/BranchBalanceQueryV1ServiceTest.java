package com.icbc.match.api.service.icbc;


import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import com.icbc.match.entity.BranchBalanceQuery;
import com.icbc.match.security.IcbcSmService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;


@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class BranchBalanceQueryV1ServiceTest {


    @Autowired
    private BranchBalanceQueryV1Service branchBalanceQueryV1Service;

    @Autowired
    private IcbcSmService icbcSmService;

    @Test
    public void branchBalanceQueryV1ServiceTest() {


        Gson gson = new Gson();


        String romdom = "FHJS025" + IdUtil.simpleUUID().substring(0, 6);
        System.out.println("romdom:" + romdom);

        Map<String, String> map = new HashMap();
        map.put("mediumId", "6214760200611509271");
//        map.put("bindMedium", "6222000200127516730");
        map = icbcSmService.encrypt(map);


        BranchBalanceQuery branchBalancequery = new BranchBalanceQuery();
        branchBalancequery.setCorp_no(ApiConstants.CORP_NO);
        branchBalancequery.setTrx_acc_date(ApiConstants.ACC_DATE);
        branchBalancequery.setTrx_acc_time("13:30:01");
        branchBalancequery.setCorp_date(ApiConstants.ACC_DATE);
        branchBalancequery.setCorp_serno(romdom);
        branchBalancequery.setOut_service_code("querybalance");
        branchBalancequery.setMedium_id(map.get("mediumId"));
        branchBalancequery.setCcy(1);
        // branchBalancequery.setMedium_id_hash("SDFDFHTEWTGDFWADADAFSDGSESEFD");
        //  branchBalancequery.setSecret_key("ASDQWEQDZCSDFAWWQDA");
        branchBalancequery.setCall_type("API");
        branchBalancequery.setSecret_key(map.get("secretKey"));

        Map result = branchBalanceQueryV1Service.branchBalancequery(branchBalancequery);

        log.info(gson.toJson(result));

        Assert.assertEquals("0", result.get("return_code").toString());


    }

}

