package com.icbc.match.api.service.icbc;

import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.entity.CertPersonalEntityEntityauth;
import com.icbc.match.utils.ImageToBasse64Util;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class CertPersonalEntityEntityauthV1ServiceTest {


    @Autowired
    private CertPersonalEntityEntityauthV1Service certPersonalEntityEntityauthV1Service;

    @Test
    public void test() {
        //本地图片转base64编码
        String imageBase64 = ImageToBasse64Util.ImageToBase64ByLocal("E:\\images\\Wechat.jpg");

        Gson gson = new Gson();
        CertPersonalEntityEntityauth certPersonalEntityEntityauth = new CertPersonalEntityEntityauth();
        certPersonalEntityEntityauth.setReqId("2019060103876etwt5435786");
        certPersonalEntityEntityauth.setChannel("4");
        certPersonalEntityEntityauth.setName("王士玉");
        certPersonalEntityEntityauth.setIdCode("370481199202294612");
        certPersonalEntityEntityauth.setPhotoData(imageBase64);
        certPersonalEntityEntityauth.setScene("02");

        Map result = certPersonalEntityEntityauthV1Service.execute(certPersonalEntityEntityauth);

        log.info(gson.toJson(result));

        Assert.assertEquals("0", result.get("return_code").toString());
    }
    @Autowired
    private TestToolService testToolService;
    @Test
    public void test1(){
    	   CertPersonalEntityEntityauth certPersonalEntityEntityauth = new CertPersonalEntityEntityauth();
           certPersonalEntityEntityauth.setReqId("2019060103876etwt5435786");
           certPersonalEntityEntityauth.setChannel("4");
           certPersonalEntityEntityauth.setName("王士玉");
           certPersonalEntityEntityauth.setIdCode("370481199202294612");
           certPersonalEntityEntityauth.setScene("02");
    	   testToolService.execute(certPersonalEntityEntityauth);
    }
}
