package com.icbc.match.api.service.ecoup;

import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class BusinessopEcoupEcoupactruleaddV1ServiceTest {

    @Autowired
    private BusinessopEcoupEcoupactruleaddV1Service businessopEcoupEcoupactruleaddV1Service;

    @Test
    public void test() {
        //本地图片转base64编码

        HashMap bizContent = new HashMap();
        Gson gson = new Gson();
        HashMap chanCommV10 = new HashMap();
        chanCommV10.put("chantype", 001);
        chanCommV10.put("chanlno", "");
        chanCommV10.put("mac", "");
        chanCommV10.put("ip", "");
        chanCommV10.put("termid", "");
        chanCommV10.put("oapp", "F-XFQ");
        chanCommV10.put("sevlevel", 1);
        chanCommV10.put("serialno", "45345345343");
        chanCommV10.put("mserialn", "");
        chanCommV10.put("oserialn", "");
        chanCommV10.put("preflag", "xxx");
        chanCommV10.put("prodid", "xxx");
        chanCommV10.put("cobprodid", "xxx");
        chanCommV10.put("cino", "xxx");
        chanCommV10.put("trxsqnb", "xxx");
        chanCommV10.put("disrecflag", "xxx");
        chanCommV10.put("comrolflag", "xxx");
        chanCommV10.put("paperlessflag", "xxx");
        chanCommV10.put("field1", "xxx");
        chanCommV10.put("termtype", "xxx");
        chanCommV10.put("launbankzoneno", "xxx");
        chanCommV10.put("fingerprinflag", "xxx");
        chanCommV10.put("distransinfo", "xxx");
        chanCommV10.put("trxnocheckflag", "xxx");
        bizContent.put("chanCommV10", chanCommV10);
        HashMap infoCommV10 = new HashMap();
        infoCommV10.put("trxtype", "xxx");
        infoCommV10.put("trxcode", "xxx");
        infoCommV10.put("zoneno", "xxx");
        infoCommV10.put("brno", "xxx");
        infoCommV10.put("tellerno", "xxx");
        infoCommV10.put("workdate", "xxx");
        infoCommV10.put("worktime", "xxx");
        infoCommV10.put("revtranf", "xxx");

        HashMap privateParams = new HashMap();
        HashMap ecou_act_info = new HashMap();
        ecou_act_info.put("ec_act_id", "xxx");
        ecou_act_info.put("ec_act_name", "xxx");
        ecou_act_info.put("act_begin_date", "xxx");
        ecou_act_info.put("act_begin_time", "xxx");
        ecou_act_info.put("act_end_date", "xxx");
        ecou_act_info.put("ec_act_status", "xxx");
        ecou_act_info.put("drawec_rule_id", "xxx");
        ecou_act_info.put("act_sum_amt", "xxx");
        ecou_act_info.put("ec_day_limit", "xxx");
        ecou_act_info.put("num_limit", "xxx");
        ecou_act_info.put("num_limit_date", "xxx");
        ecou_act_info.put("amount_limit", "xxx");
        ecou_act_info.put("amount_limit_date", "xxx");
        ecou_act_info.put("order_count_limit", "xxx");
        ecou_act_info.put("order_user_count_limit", "xxx");
        ecou_act_info.put("user_type", "xxx");
        ecou_act_info.put("inner_type", "xxx");
        ecou_act_info.put("inner_account", "xxx");
        ecou_act_info.put("phyorgno", "xxx");
        ecou_act_info.put("area_code_h", "xxx");
        ecou_act_info.put("net_code_h", "xxx");
        ecou_act_info.put("atrxcode", "xxx");
        ecou_act_info.put("business_type", "xxx");
        ecou_act_info.put("act_channel", "xxx");
        ecou_act_info.put("is_present", "xxx");
        ecou_act_info.put("linkman_name", "xxx");
        ecou_act_info.put("linkman_mobile_no", "xxx");
        ecou_act_info.put("gift_act_des", "xxx");
        ecou_act_info.put("gift_act_note", "xxx");
        ecou_act_info.put("gift_act_corp", "xxx");
        ecou_act_info.put("notes_id", "xxx");
        ecou_act_info.put("stru_name", "xxx");
        ecou_act_info.put("sign_zoneno", "xxx");
        ecou_act_info.put("sign_brno", "xxx");
        ecou_act_info.put("sign_teller", "xxx");
        ecou_act_info.put("sign_time", "xxx");
        ecou_act_info.put("appr_zoneno", "xxx");
        ecou_act_info.put("appr_brno", "xxx");
        ecou_act_info.put("appr_teller", "xxx");
        ecou_act_info.put("appr_time", "xxx");
        ecou_act_info.put("last_update_time", "xxx");
        HashMap ecou_act_rule = new HashMap();
        ecou_act_rule.put("ec_act_id", "xxx");
        ecou_act_rule.put("ec_act_rule_name", "xxx");
        ecou_act_rule.put("ec_gen_type", "xxx");
        ecou_act_rule.put("ec_type", "xxx");
        ecou_act_rule.put("use_channel", "xxx");
        ecou_act_rule.put("pay_way", "xxx");
        ecou_act_rule.put("rule_status", "xxx");
        ecou_act_rule.put("getec_rule_id", "xxx");
        ecou_act_rule.put("rule_begin_date", "xxx");
        ecou_act_rule.put("rule_end_date", "xxx");
        ecou_act_rule.put("ec_count", "xxx");
        ecou_act_rule.put("ec_num_limit", "xxx");
        ecou_act_rule.put("ec_day_limit", "xxx");
        ecou_act_rule.put("ec_amount_gentype", "xxx");
        ecou_act_rule.put("ec_amount_value", "xxx");
        ecou_act_rule.put("ran_sum_value", "xxx");
        ecou_act_rule.put("ran_min_value", "xxx");
        ecou_act_rule.put("ran_max_value", "xxx");
        ecou_act_rule.put("step_value", "xxx");
        ecou_act_rule.put("rule_des", "xxx");
        ecou_act_rule.put("rule_note", "xxx");
        ecou_act_rule.put("ecoupon_type", "xxx");
        ecou_act_rule.put("order_amt_limit", "xxx");
        ecou_act_rule.put("use_starting_point", "xxx");
        ecou_act_rule.put("grant_target", "xxx");
        ecou_act_rule.put("effect_time_space", "xxx");
        ecou_act_rule.put("effect_begin_date", "xxx");
        ecou_act_rule.put("lasting_type", "xxx");
        ecou_act_rule.put("effect_time_step", "xxx");
        ecou_act_rule.put("effect_end_date", "xxx");
        ecou_act_rule.put("effect_begin_time", "xxx");
        ecou_act_rule.put("intf_store_ids", "xxx");
        ecou_act_rule.put("entity_id", "xxx");
        ecou_act_rule.put("ec_gened_count", "xxx");
        ecou_act_rule.put("last_update_time", "xxx");
        privateParams.put("operflag", 1);
        privateParams.put("ecou_act_info", ecou_act_info);
        privateParams.put("ecou_act_rule", ecou_act_rule);


        bizContent.put("privateParams", privateParams);

        Map<String, Object> result = businessopEcoupEcoupactruleaddV1Service.execute(bizContent);
        log.info("返回报文：{}", gson.toJson(result));

    }
}
