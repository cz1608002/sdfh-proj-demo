package com.icbc.match.api.service.cop;

import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.api.request.B2cPassfreePaymentTerminateRequestV1;
import com.icbc.api.response.B2cPassfreePaymentTerminateResponseV1;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.security.IcbcSmService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class B2cPassfreePaymentTerminateV1ServiceTest {

    @Autowired
    private B2cPassfreePaymentTerminateV1Service b2cPassfreePaymentTerminateV1Service;

    @Autowired
    private IcbcSmService icbcSmService;

    @Test
    public void test() {


        Map<String, String> map = new HashMap();
        map.put("bindMedium", "6212260200140208055");
        map = icbcSmService.encrypt(map);

        String serNo = "FHJS025" + IdUtil.simpleUUID().substring(0, 9);
        String cisNo = IdUtil.simpleUUID();//合作方客户号
        log.info("serNo:{},cisNo:{}", serNo, cisNo);

        Gson gson = new Gson();
        B2cPassfreePaymentTerminateRequestV1.B2cPassfreePaymentTerminateRequestV1Biz bizContent = new B2cPassfreePaymentTerminateRequestV1.B2cPassfreePaymentTerminateRequestV1Biz();
        bizContent.setConsumerId("fhjs025");
        B2cPassfreePaymentTerminateResponseV1 response = b2cPassfreePaymentTerminateV1Service.execute(bizContent);

        log.info(gson.toJson(response));

    }
}
