package com.icbc.match.api.service.icbc;


import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import com.icbc.match.entity.BranchWithdraw;
import com.icbc.match.security.IcbcSmService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;


@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class BranchWithdrawV1ServiceTest {


    @Autowired
    private BranchWithdrawV1Service branchWithdrawV1Service;

    @Autowired
    private IcbcSmService icbcSmService;

    @Test
    public void BranchWithdrawV1STest() {

        Gson gson = new Gson();


        String serno = "FHJS025" + IdUtil.simpleUUID().substring(0, 6);
        System.out.println("romdom:" + serno);

        Map<String, String> map = new HashMap();
        map.put("mediumId", "6214760200611509271");
        map.put("bindMedium", "6222000200127516730");
        map = icbcSmService.encrypt(map);

        BranchWithdraw branchWithdraw = new BranchWithdraw();
        branchWithdraw.setCorp_no(ApiConstants.CORP_NO);
        branchWithdraw.setTrx_acc_date(ApiConstants.ACC_DATE);
        branchWithdraw.setTrx_acc_time("13:30:01");
        branchWithdraw.setCorp_date(ApiConstants.ACC_DATE);
        branchWithdraw.setCorp_serno(serno);
        branchWithdraw.setOut_service_code("withdraw");
        branchWithdraw.setMedium_id(map.get("mediumId"));
        branchWithdraw.setBind_medium(map.get("bindMedium"));
        branchWithdraw.setCcy(1);
        branchWithdraw.setCash_ex_flag(0);
        branchWithdraw.setAmount("100");
        branchWithdraw.setSummary("提现");
        branchWithdraw.setRemarks("提现");
        branchWithdraw.setCall_type("API");
        branchWithdraw.setNotify_addr("aaaaa");
        branchWithdraw.setSecret_key(map.get("secretKey")  );

        Map result = branchWithdrawV1Service.branchWithdraw(branchWithdraw);

        log.info(gson.toJson(result));

        Assert.assertEquals("0", result.get("return_code").toString());


    }

}

