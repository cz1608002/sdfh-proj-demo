package com.icbc.match.api.service.cop;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.api.request.DepositFixedProdqueryRequestV1;
import com.icbc.api.response.DepositFixedProdqueryResponseV1;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class DepositFixedProdqueryV1ServiceTest {

    @Autowired
    private DepositFixedProdqueryV1Service depositFixedProdqueryV1Service;

    @Test
    public void test() {


        String serNo = "FHJS025" + IdUtil.simpleUUID().substring(0, 9);
        String cisNo = IdUtil.simpleUUID();//合作方客户号
        log.info("serNo:{},cisNo:{}", serNo, cisNo);

        Gson gson = new Gson();
        DepositFixedProdqueryRequestV1.DepositFixedProdqueryRequestV1Biz bizContent = new DepositFixedProdqueryRequestV1.DepositFixedProdqueryRequestV1Biz();
        bizContent.setCmExternalEventNo(serNo);
        bizContent.setCmAppId(ApiConstants.CORP_NO);
        bizContent.setCmWorkdate(ApiConstants.ACC_DATE);
        bizContent.setCmWorktime(DateUtil.formatTime(DateUtil.date()));
        bizContent.setQryType("1");
        bizContent.setStart("0");
        bizContent.setRows("10");
        DepositFixedProdqueryResponseV1 response = depositFixedProdqueryV1Service.execute(bizContent);

        log.info(gson.toJson(response));

    }
}
