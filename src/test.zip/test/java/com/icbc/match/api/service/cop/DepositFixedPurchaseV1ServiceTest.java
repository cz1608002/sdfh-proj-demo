package com.icbc.match.api.service.cop;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.api.request.DepositFixedPurchaseRequestV1;
import com.icbc.api.response.DepositFixedPurchaseResponseV1;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import com.icbc.match.security.IcbcSmService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class DepositFixedPurchaseV1ServiceTest {

    @Autowired
    private DepositFixedPurchaseV1Service depositFixedPurchaseV1Service;

    @Autowired
    private IcbcSmService icbcSmService;

    @Test
    public void test() {
        Map<String, String> map = new HashMap();
        map.put("mediumId", "6214760200611510378");
        map = icbcSmService.encrypt(map);

        String serNo = "FHJS025" + IdUtil.simpleUUID().substring(0, 9);
        String cisNo = IdUtil.simpleUUID();//合作方客户号
        log.info("serNo:{},cisNo:{}", serNo, cisNo);

        Gson gson = new Gson();
        DepositFixedPurchaseRequestV1.DepositFixedPurchaseRequestV1Biz bizContent = new DepositFixedPurchaseRequestV1.DepositFixedPurchaseRequestV1Biz();
        bizContent.setExternalEventNo(serNo);
        bizContent.setAppId(ApiConstants.CORP_NO);
        bizContent.setWorkdate(ApiConstants.ACC_DATE);
        bizContent.setWorktime(DateUtil.formatTime(DateUtil.date()));
        bizContent.setOutServiceCode("fixedpurchase");
        bizContent.setSecretKey(map.get("secretKey"));
        bizContent.setMediumId(map.get("mediumId"));
        bizContent.setProdCode("010030000043");
        bizContent.setTerm("003");
        bizContent.setCashExFlag("0");
        bizContent.setCcy("1");
        bizContent.setAmount("10000");
        DepositFixedPurchaseResponseV1 response = depositFixedPurchaseV1Service.execute(bizContent);

        log.info(gson.toJson(response));

    }
}
