package com.icbc.match.api.service.icbc;


import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.entity.BranchBinding;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;


@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class BranchBindingV1ServiceTest {


    @Autowired
    private BranchBindingV1Service branchBindingV1Service;

    @Test
    public void branchBindingV1Test() {

        Gson gson = new Gson();
        BranchBinding branchBinding = new BranchBinding();
        branchBinding.setCorp_no("corpInst1234");
        branchBinding.setTrx_acc_date("2017-03-15");
        branchBinding.setTrx_acc_time("13:30:01");
        branchBinding.setCorp_date("2017-03-15");
        branchBinding.setCorp_serno("ABC987654321");
        branchBinding.setOut_service_code("binding");
        branchBinding.setCorp_cis_no("113");
        branchBinding.setCorp_medium_id("113");
        branchBinding.setMedium_id("6214760200000022233");
        branchBinding.setBind_medium("6214760200000022233");
        branchBinding.setCert_type(0);
        branchBinding.setCert_no("999999199009099991");
        branchBinding.setCust_name("九九九九九九九九九九九九九九九");
        branchBinding.setMobile_no("13611223388");
        branchBinding.setNotify_addr("aaaaa");
        branchBinding.setSecret_key("ASDQWEQDZCSDFAWWQDA");
        branchBinding.setMedium_id_hash("SDFDFHTEWTGDFWADADAFSDGSESEFD");
        branchBinding.setBind_medium_hash("SDFDFHTEWTGDFWADADAFSDGSESEFD");




        Map result = branchBindingV1Service.branchBinding(branchBinding);

        log.info(gson.toJson(result));

        Assert.assertEquals("0", result.get("return_code").toString());


    }

}

