package com.icbc.match.api.service.icbc;

import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.entity.SettlementAccountBranchRealtimeimgUpload;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class SettlementAccountBranchRealtimeimgUploadV1ServiceTest {

    @Autowired
    private SettlementAccountOpenRealtimeimgUploadV1Service settlementAccountOpenRealtimeimgUploadV1Service;

    @Test
    public void test() {

        Gson gson = new Gson();
        SettlementAccountBranchRealtimeimgUpload settlementAccountBranchRealtimeimgUpload = new SettlementAccountBranchRealtimeimgUpload();
        settlementAccountBranchRealtimeimgUpload.setCorpNo("corpInst1234");
        settlementAccountBranchRealtimeimgUpload.setTrxAccDate("2020-12-12");
        settlementAccountBranchRealtimeimgUpload.setTrxAccTime("13:30:01");
        settlementAccountBranchRealtimeimgUpload.setCorpSerno("13535536");
        settlementAccountBranchRealtimeimgUpload.setOutServiceCode("uploadimg");
        settlementAccountBranchRealtimeimgUpload.setCertNo("370481199202294612");
        settlementAccountBranchRealtimeimgUpload.setCustName("王士玉");
        settlementAccountBranchRealtimeimgUpload.setValidityPeriod("2039-07-06");
        settlementAccountBranchRealtimeimgUpload.setFrontImgType("01");
        settlementAccountBranchRealtimeimgUpload.setFrontImg("13611223388");
        settlementAccountBranchRealtimeimgUpload.setBackImgType("01");
        settlementAccountBranchRealtimeimgUpload.setBackImg("aaaaabbbbb");
        settlementAccountBranchRealtimeimgUpload.setSecretKey("");
        settlementAccountBranchRealtimeimgUpload.setClearFlag(0);
        settlementAccountBranchRealtimeimgUpload.setFaceImgType("03");
        settlementAccountBranchRealtimeimgUpload.setFaceImg("");

        Map result = settlementAccountOpenRealtimeimgUploadV1Service.execute(settlementAccountBranchRealtimeimgUpload);

        log.info(gson.toJson(result));

        Assert.assertEquals("0", result.get("return_code").toString());
    }
}
