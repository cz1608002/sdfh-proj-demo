package com.icbc.match.api.service.icbc;

import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import com.icbc.match.entity.SettlementAccountBranchScodeSend;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class SettlementAccountBranchScodeSendV1ServiceTest {

    @Autowired
    private SettlementAccountBranchScodeSendV1Service settlementAccountBranchScodeSendV1Service;

    @Test
    public void test() {
        //本地图片转base64编码

        Gson gson = new Gson();
        String romdom = "FHJS025" + IdUtil.simpleUUID().substring(0, 6);
        System.out.println("romdom:" + romdom);


        SettlementAccountBranchScodeSend settlementAccountBranchScodeSend = new SettlementAccountBranchScodeSend();
        settlementAccountBranchScodeSend.setCorpNo(ApiConstants.CORP_NO);
        settlementAccountBranchScodeSend.setTrxAccDate(ApiConstants.ACC_DATE);
        settlementAccountBranchScodeSend.setTrxAccTime("13:30:01");
        settlementAccountBranchScodeSend.setCorpDate(ApiConstants.ACC_DATE);
        settlementAccountBranchScodeSend.setCorpSerno(romdom);
        settlementAccountBranchScodeSend.setOutServiceCode("openaccount");
        settlementAccountBranchScodeSend.setCorpSernoOriginal("FHJS025b6e58b");

        Map result = settlementAccountBranchScodeSendV1Service.execute(settlementAccountBranchScodeSend);

        //成功后需要用新的CorpSerno 替换原订单号
        log.info(gson.toJson(result));

        Assert.assertEquals("0", result.get("return_code").toString());
    }

}
