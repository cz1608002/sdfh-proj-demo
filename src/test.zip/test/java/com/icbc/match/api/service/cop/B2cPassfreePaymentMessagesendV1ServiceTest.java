package com.icbc.match.api.service.cop;

import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.api.request.B2cPassfreePaymentMessagesendRequestV1;
import com.icbc.api.response.B2cPassfreePaymentMessagesendResponseV1;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class B2cPassfreePaymentMessagesendV1ServiceTest {

    @Autowired
    private B2cPassfreePaymentMessagesendV1Service b2cPassfreePaymentMessagesendV1Service;

    @Test
    public void test() {


        String serNo = "FHJS025" + IdUtil.simpleUUID().substring(0, 9);
        String cisNo = IdUtil.simpleUUID();//合作方客户号
        log.info("serNo:{},cisNo:{}", serNo, cisNo);

        Gson gson = new Gson();
        B2cPassfreePaymentMessagesendRequestV1.B2cPassfreePaymentMsgSendRequestV1Biz bizContent = new B2cPassfreePaymentMessagesendRequestV1.B2cPassfreePaymentMsgSendRequestV1Biz();
        bizContent.setMerchantId(ApiConstants.CORP_NO);
        bizContent.setMerchantType("1");
        bizContent.setMobile("18501366157");
        bizContent.setPartnerFlag("1");
        bizContent.setShopName("广研饭堂钱包");
        bizContent.setCardno("6214760200611510378");
        B2cPassfreePaymentMessagesendResponseV1 response = b2cPassfreePaymentMessagesendV1Service.execute(bizContent);

        log.info(gson.toJson(response));

    }
}
