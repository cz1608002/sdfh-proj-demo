package com.icbc.match.api.service.icbc;

import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import com.icbc.match.entity.SettlementAccountBranchScodeVerify;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class SettlementAccountBranchScodeVerifyV1ServiceTest {
    @Autowired
    private SettlementAccountBranchScodeVerifyV1Service settlementAccountBranchScodeVerifyV1Service;

    @Test
    public void test() {


        Gson gson = new Gson();
        SettlementAccountBranchScodeVerify settlementAccountBranchScodeVerify = new SettlementAccountBranchScodeVerify();
        settlementAccountBranchScodeVerify.setCorpNo(ApiConstants.CORP_NO);
        settlementAccountBranchScodeVerify.setTrxAccDate(ApiConstants.ACC_DATE);
        settlementAccountBranchScodeVerify.setTrxAccTime("12:12:30");
        settlementAccountBranchScodeVerify.setCorpDate(ApiConstants.ACC_DATE);
        settlementAccountBranchScodeVerify.setCorpSerno(ApiConstants.FHJS025 + IdUtil.simpleUUID().substring(0,6));
        settlementAccountBranchScodeVerify.setOutServiceCode("scodeverify");
        settlementAccountBranchScodeVerify.setCorpSernoOriginal("FHJS025b6e58b");
        settlementAccountBranchScodeVerify.setSmsSendNo("880347");
        settlementAccountBranchScodeVerify.setSmsScode("955888");
        Map result = settlementAccountBranchScodeVerifyV1Service.execute(settlementAccountBranchScodeVerify);

        log.info(gson.toJson(result));


    }
}
