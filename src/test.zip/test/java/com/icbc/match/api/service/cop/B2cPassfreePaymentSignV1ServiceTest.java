package com.icbc.match.api.service.cop;

import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.api.request.B2cPassfreePaymentSignRequestV1;
import com.icbc.api.response.B2cPassfreePaymentSignResponseV1;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class B2cPassfreePaymentSignV1ServiceTest {

    @Autowired
    private B2cPassfreePaymentSignV1Service b2cPassfreePaymentSignV1Service;

    @Test
    public void test() {
        Map<String, String> map = new HashMap();
        map.put("certNo", "125457198102061284");
        map.put("custName", "躯亩");
        map.put("bindMedium", "6212260200140208055");
        map.put("mobile", "18501366157");

        String serNo = "FHJS025" + IdUtil.simpleUUID().substring(0, 9);
        String cisNo = IdUtil.simpleUUID();//合作方客户号
        log.info("serNo:{},cisNo:{}", serNo, cisNo);

        Gson gson = new Gson();
        B2cPassfreePaymentSignRequestV1.B2cPassfreePaymentSignRequestV1Biz bizContent = new B2cPassfreePaymentSignRequestV1.B2cPassfreePaymentSignRequestV1Biz();
        bizContent.setExternalId(ApiConstants.CORP_MEDIUM_ID);
        bizContent.setMerchantId(ApiConstants.CORP_NO);
        bizContent.setMerchantAcct("6214760200611510378");
        bizContent.setMerchantType("1");
        bizContent.setMobile("18501366157");
        bizContent.setCardno("6214760200611510378");
        bizContent.setCustName("躯亩");
        bizContent.setCustCertType("0");
        bizContent.setCustCertNo("125457198102061284");
        bizContent.setMessageFlag("1");
        bizContent.setUmsMsgNo("");
        bizContent.setUmsVerifyCode("");
        B2cPassfreePaymentSignResponseV1 response = b2cPassfreePaymentSignV1Service.execute(bizContent);

        log.info(gson.toJson(response));

    }
}
