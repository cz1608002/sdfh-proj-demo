package com.icbc.match.api.service.icbc;


import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.entity.AccountReserve;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;


@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class AccountReserveV1ServiceTest {


    @Autowired
    private AccountReserveV1Service accountReserveV1Service;

    @Test
    public void accountStatusQueryServiceTest() {


        Gson gson = new Gson();

        AccountReserve accountReserve = new AccountReserve();

        accountReserve.setZoneno("1611");
        accountReserve.setBrno("00800");
        accountReserve.setMdCardno("6222021611012055680");
        accountReserve.setChDate("2021-10-10");
        accountReserve.setHoldCeil(100);
        accountReserve.setOpType("1");


        Map result = accountReserveV1Service.accountReserve(accountReserve);

        log.info(gson.toJson(result));

        Assert.assertEquals("0", result.get("return_code").toString());
    }



}

