package com.icbc.match.api.service.icbc;


import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import com.icbc.match.entity.AccountStatusQuery;

import com.icbc.match.security.IcbcSmService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;


@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class AccountStatusQueryServiceTest {


    @Autowired
    private AccountStatusQueryService accountStatusQueryService;

    @Autowired
    private IcbcSmService icbcSmService;

    @Test
    public void accountStatusQueryServiceTest() {


        Gson gson = new Gson();
        String serno = "FHJS025" + IdUtil.simpleUUID().substring(0, 6);
        log.info("@@FHJS025:" + serno);

        AccountStatusQuery accountStatusQuery = new AccountStatusQuery();
        accountStatusQuery.setOutServiceCode("querystatus");
        accountStatusQuery.setCorpNo(ApiConstants.CORP_NO);
        accountStatusQuery.setCorpSerno(serno);
        accountStatusQuery.setCorpMediumId("6214760200611509271");
        accountStatusQuery.setCallType("API");


        Map result = accountStatusQueryService.accountStatusQuery(accountStatusQuery);

//        Map decodeMap = new HashMap();
        log.info(gson.toJson(result));
        result.remove("cert_type");
        result.remove("bindInfoList");
        result.remove("card_stat");
        result.remove("account_level");
        result.remove("return_msg");
        result.remove("corp_cis_no");
        result.remove("message");
        result.remove("account_org_no");
        result.remove("corp_name");
        result.remove("cert_flag");
        result.remove("cust_cis_no");
        result.remove("return_code");
        result.put("secretKey",result.get("secret_key").toString());
        result.remove("secret_key");
//        icbcSmService.decrypt(result);
        log.info(gson.toJson(icbcSmService.decrypt(result)));

//        Assert.assertEquals("0", result.get("return_code").toString());


    }

}

