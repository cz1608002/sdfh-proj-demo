package com.icbc.match.api.service.cop;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.api.request.DepositFixedQueryRequestV1;
import com.icbc.api.response.DepositFixedQueryResponseV1;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import com.icbc.match.security.IcbcSmService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class DepositFixedQueryV1ServiceTest {

    @Autowired
    private DepositFixedQueryV1Service depositFixedQueryV1Service;

    @Autowired
    private IcbcSmService icbcSmService;

    @Test
    public void test() {
        Map<String, String> map = new HashMap();
        map.put("mediumId", "6214760200611510378");
        map = icbcSmService.encrypt(map);

        String serNo = "FHJS025" + IdUtil.simpleUUID().substring(0, 9);
        String cisNo = IdUtil.simpleUUID();//合作方客户号
        log.info("serNo:{},cisNo:{}", serNo, cisNo);

        Gson gson = new Gson();
        DepositFixedQueryRequestV1.DepositFixedQueryRequestV1Biz bizContent = new DepositFixedQueryRequestV1.DepositFixedQueryRequestV1Biz();
        bizContent.setAppId(ApiConstants.CORP_NO);
        bizContent.setWorkdate(ApiConstants.ACC_DATE);
        bizContent.setWorktime(DateUtil.formatTime(DateUtil.date()));
        bizContent.setExternalEventNo(serNo);
        bizContent.setOutServiceCode("fixedquery");
        bizContent.setSecretKey(map.get("secretKey"));
        bizContent.setMediumId(map.get("mediumId"));
        bizContent.setQueryFlag("1");
        bizContent.setPageNum("10");
        DepositFixedQueryResponseV1 response = depositFixedQueryV1Service.execute(bizContent);

        log.info(gson.toJson(response));

    }
}
