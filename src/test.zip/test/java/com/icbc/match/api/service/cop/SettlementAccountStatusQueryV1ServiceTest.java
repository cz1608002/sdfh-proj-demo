package com.icbc.match.api.service.cop;

import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.api.request.SettlementAccountStatusQueryRequestV1;
import com.icbc.api.response.SettlementAccountStatusQueryResponseV1;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import com.icbc.match.security.IcbcSmService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class SettlementAccountStatusQueryV1ServiceTest {

    @Autowired
    private SettlementAccountStatusQueryV1Service settlementAccountStatusQueryV1Service;

    @Autowired
    private IcbcSmService icbcSmService;

    @Test
    public void test() {

        Gson gson = new Gson();

        Map<String, String> map = new HashMap();
        map.put("mediumId", "6214760200611510378");
        map = icbcSmService.encrypt(map);

        String serno = "FHJS025" + IdUtil.simpleUUID().substring(0, 6);
        log.info("serno:" + serno);
        SettlementAccountStatusQueryRequestV1.SettlementAccountStatusQueryRequestV1Biz bizContent = new SettlementAccountStatusQueryRequestV1.SettlementAccountStatusQueryRequestV1Biz();
        bizContent.setOutServiceCode("querystatus");
        bizContent.setCorpSerno(serno);
        bizContent.setCorpNo(ApiConstants.CORP_NO);
        bizContent.setCorpMediumId(ApiConstants.CORP_MEDIUM_ID);
        bizContent.setSummary("查询");
        bizContent.setRemarks("查询");
        bizContent.setMediumId(map.get("mediumId"));
        bizContent.setSecretKey(map.get("secretKey"));

        SettlementAccountStatusQueryResponseV1 response = settlementAccountStatusQueryV1Service.execute(bizContent);

        log.info("api返回报文：{}", gson.toJson(response));
    }
}
