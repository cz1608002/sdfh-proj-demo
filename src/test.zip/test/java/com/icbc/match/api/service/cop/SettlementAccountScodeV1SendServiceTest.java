package com.icbc.match.api.service.cop;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.api.request.SettlementAccountSCodeSendRequestV1;
import com.icbc.api.response.SettlementAccountSCodeSendResponseV1;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class SettlementAccountScodeV1SendServiceTest {

    @Autowired
    private SettlementAccountScodeV1SendService settlementAccountScodeV1SendService;

    @Test
    public void test() {
        //本地图片转base64编码

        Gson gson = new Gson();
        String serNo = "FHJS025" + IdUtil.simpleUUID().substring(0, 6);
        log.info("serNo:{}", serNo);

        SettlementAccountSCodeSendRequestV1.SettlementAccountSCodeRequestV1Biz bizContent = new SettlementAccountSCodeSendRequestV1.SettlementAccountSCodeRequestV1Biz();

        bizContent.setCorpNo(ApiConstants.CORP_NO);
        bizContent.setTrxAccDate(ApiConstants.ACC_DATE);
        bizContent.setTrxAccTime(DateUtil.formatTime(DateUtil.date()));
        bizContent.setCorpDate(ApiConstants.ACC_DATE);
        bizContent.setCorpSerno(serNo);
        bizContent.setOutServiceCode("scode");
        bizContent.setCorpSernoOriginal("FHJS025cff97066b");

        SettlementAccountSCodeSendResponseV1 response = settlementAccountScodeV1SendService.execute(bizContent);

        //成功后需要用新的CorpSerno 替换原订单号
        log.info(gson.toJson(response));

    }

}
