package com.icbc.match.api.service.cop;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.api.request.SettlementAccountBindingRequestV1;
import com.icbc.api.response.SettlementAccountBindingResponseV1;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import com.icbc.match.security.IcbcSmService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class SettlementAccountV1BindingServiceTest {

    @Autowired
    private SettlementAccountV1BindingService settlementAccountV1BindingService;

    @Autowired
    private IcbcSmService icbcSmService;

    @Test
    public void test() {

        Map<String, String> map = new HashMap();
        map.put("certNo", "125457198102061284");
        map.put("custName", "躯亩");
        map.put("bindMedium", "6212260200140208055");
        map.put("mobile", "18501366157");
        map.put("mediumId", "6214760200611510378");
        map = icbcSmService.encrypt(map);

        String serNo = "FHJS025" + IdUtil.simpleUUID().substring(0, 9);
        String cisNo = "0701f4d288574ad9907021f9cf71d4eb";//合作方客户号
        log.info("serNo:{},cisNo:{}", serNo, cisNo);

        Gson gson = new Gson();
        SettlementAccountBindingRequestV1.SettlementAccountBindingRequestV1Biz bizContent = new SettlementAccountBindingRequestV1.SettlementAccountBindingRequestV1Biz();
        bizContent.setCorpNo(ApiConstants.CORP_NO);
        bizContent.setTrxAccDate(ApiConstants.ACC_DATE);
        bizContent.setTrxAccTime(DateUtil.formatTime(DateUtil.date()));
        bizContent.setCorpDate(ApiConstants.ACC_DATE);
        bizContent.setCorpSerno(serNo);
        bizContent.setOutServiceCode("binding");
        bizContent.setCorpMediumId(ApiConstants.CORP_MEDIUM_ID);
        bizContent.setMediumId(map.get("mediumId"));
        bizContent.setBindMedium(map.get("bindMedium"));
        bizContent.setCertType(0);
        bizContent.setCertNo(map.get("certNo"));
        bizContent.setCustName(map.get("custName"));
        bizContent.setMobileNo(map.get("mobile"));
        bizContent.setSecretKey(map.get("secretKey"));

        SettlementAccountBindingResponseV1 response = settlementAccountV1BindingService.execute(bizContent);

        log.info(gson.toJson(response));
    }
}
