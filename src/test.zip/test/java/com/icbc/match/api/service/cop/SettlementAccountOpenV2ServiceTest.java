package com.icbc.match.api.service.cop;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.api.request.SettlementAccountOpenRequestV2;
import com.icbc.api.response.SettlementAccountOpenResponseV2;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import com.icbc.match.security.IcbcSmService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class SettlementAccountOpenV2ServiceTest {

    @Autowired
    private SettlementAccountOpenV2Service settlementAccountOpenV2Service;

    @Autowired
    private IcbcSmService icbcSmService;

    @Test
    public void test() {


        Map<String, String> map = new HashMap();
        map.put("certNo", "125457198102061284");
        map.put("custName", "躯亩");
        map.put("bindMedium", "6212260200140208055");
        map.put("mobile", "18501366157");
        map = icbcSmService.encrypt(map);

        String serNo = "FHJS025" + IdUtil.simpleUUID().substring(0, 9);
        String cisNo = IdUtil.simpleUUID();//合作方客户号
        log.info("serNo:{},cisNo:{}", serNo, cisNo);

        Gson gson = new Gson();
        SettlementAccountOpenRequestV2.SettlementAccountOpenRequestV2Biz bizContent = new SettlementAccountOpenRequestV2.SettlementAccountOpenRequestV2Biz();
        bizContent.setCorpNo(ApiConstants.CORP_NO);
        bizContent.setTrxAccDate(ApiConstants.ACC_DATE);
        bizContent.setTrxAccTime(DateUtil.formatTime(DateUtil.date()));
        bizContent.setCorpDate(ApiConstants.ACC_DATE);
        bizContent.setCorpSerno(serNo);
        bizContent.setOutServiceCode("openaccount");
        bizContent.setCorpCisNo(ApiConstants.CORP_MEDIUM_ID);
        bizContent.setCorpMediumId(serNo);
        bizContent.setBindMedium(map.get("bindMedium"));
        bizContent.setCertType(0);
        bizContent.setCertNo(map.get("certNo"));
        bizContent.setCustName(map.get("custName"));
        bizContent.setMobileNo(map.get("mobile"));
        bizContent.setGender(1);
        bizContent.setOccupation(3);
        bizContent.setForeverFlag(0);
        bizContent.setSignDate("2018-12-01");  //签发日期
        bizContent.setValidityPeriod("2033-12-11");  //失效日期
        bizContent.setNationality(156);
        bizContent.setTaxDeclarationFlag(1);
        bizContent.setSecretKey(map.get("secretKey"));
        bizContent.setAddress("济南市中区经四路");
        bizContent.setAccountOrgNo("0160200800");
        bizContent.setProvince("山东省");
        bizContent.setCity("济南市");


        SettlementAccountOpenResponseV2 response = settlementAccountOpenV2Service.execute(bizContent);

        log.info(gson.toJson(response));

    }
}
