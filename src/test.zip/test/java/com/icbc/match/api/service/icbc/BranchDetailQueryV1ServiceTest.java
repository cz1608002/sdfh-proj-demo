package com.icbc.match.api.service.icbc;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.hutool.core.util.IdUtil;
import com.icbc.match.config.ApiConstants;
import com.icbc.match.security.IcbcSmService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.entity.BranchDetailQuery;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class BranchDetailQueryV1ServiceTest {

    @Autowired
    private BranchDetailQueryV1Service branchDetailQueryV1Service;

    @Autowired
    private IcbcSmService icbcSmService;

    @Test
    public void branchDetailQueryV1Test() {

        Gson gson = new Gson();

        Map<String, String> map = new HashMap();
        map.put("mediumId", "6214760200611509271");
        map.put("bindMedium", "6222000200127516730");
        map = icbcSmService.encrypt(map);

        System.out.println(gson.toJson(icbcSmService.encrypt(map)));
        String serno = "FHJS025" + IdUtil.simpleUUID().substring(0, 6);
        log.info("@@:" + serno);


        BranchDetailQuery branchDetailQuery = new BranchDetailQuery();
        branchDetailQuery.setCorp_no(ApiConstants.CORP_NO);
        branchDetailQuery.setTrx_acc_date(ApiConstants.ACC_DATE);
        branchDetailQuery.setTrx_acc_time("12:30:21");
        branchDetailQuery.setCorp_date(ApiConstants.ACC_DATE);
        branchDetailQuery.setCorp_serno(serno);
        branchDetailQuery.setOut_service_code("querydetail");
        branchDetailQuery.setMedium_id(map.get("mediumId"));
        branchDetailQuery.setCcy(1);
        branchDetailQuery.setBegin_date("2020-12-03");
        branchDetailQuery.setEnd_date("2020-12-30");
        branchDetailQuery.setQuery_mode(1);
        branchDetailQuery.setPage(1);
        branchDetailQuery.setMedium_id_hash("");
        branchDetailQuery.setSecret_key(map.get("secretKey"));
        branchDetailQuery.setCall_type("API");

        log.info("request请求参数:" + branchDetailQuery.toString());
        Map result = branchDetailQueryV1Service.branchDetailquery(branchDetailQuery);
        log.info(gson.toJson(result));

        List<Map<String, String>> list = (List) result.get("order_detail");

        String secretKey = result.get("secret_key").toString();

        for (Map map1 : list) {
            Map smMap = new HashMap();
            if (!StringUtils.isEmpty(map1.get("cp_medium_id"))) {
                smMap.put("cp_medium_id", map1.get("cp_medium_id"));
            }
            if (!StringUtils.isEmpty(map1.get("resav_name"))) {
                smMap.put("resav_name", map1.get("resav_name"));
            }
            if (!StringUtils.isEmpty(map1.get("medium_id"))) {
                smMap.put("medium_id", map1.get("medium_id"));
            }
            smMap.put("secretKey", secretKey);
            smMap = icbcSmService.decrypt(smMap);

            map1.put("cp_medium_id", smMap.get("cp_medium_id"));
            map1.put("resav_name", smMap.get("resav_name"));
            map1.put("medium_id", smMap.get("medium_id"));


        }

        log.info("解密报文：{}", gson.toJson(list));


        Assert.assertEquals("0", result.get("return_code").toString());

    }

}
