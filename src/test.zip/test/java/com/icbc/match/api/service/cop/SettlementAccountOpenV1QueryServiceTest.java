package com.icbc.match.api.service.cop;

import cn.hutool.core.util.IdUtil;
import com.google.gson.Gson;
import com.icbc.api.request.SettlementAccountOpenQueryRequestV1;
import com.icbc.api.response.SettlementAccountOpenQueryResponseV1;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.config.ApiConstants;
import com.icbc.match.security.IcbcSmService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class SettlementAccountOpenV1QueryServiceTest {

    @Autowired
    private SettlementAccountOpenV1QueryService settlementAccountOpenV1QueryService;

    @Autowired
    private IcbcSmService icbcSmService;

    @Test
    public void test() {

        Gson gson = new Gson();

        String serno = "FHJS025" + IdUtil.simpleUUID().substring(0, 6);
        log.info("serno:" + serno);
        SettlementAccountOpenQueryRequestV1.SettlementAccountOpenQueryRequestV1Biz bizContent = new SettlementAccountOpenQueryRequestV1.SettlementAccountOpenQueryRequestV1Biz();
        bizContent.setCorpNo(ApiConstants.CORP_NO);
        bizContent.setOutServiceCode("queryopenbook");
        bizContent.setOpenCorpSerno("FHJS025dcee791f0");

        SettlementAccountOpenQueryResponseV1 response = settlementAccountOpenV1QueryService.execute(bizContent);

        log.info("api返回报文：{}", gson.toJson(response));

    }
}
