package com.icbc.match.api.service.icbc;


import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.entity.BranchBindingQuery;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;


@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class BranchBindingQueryServiceTest {


    @Autowired
    private BranchBindingQueryService branchBindingQueryService;

    @Test
    public void branchBindingQueryTest() {

        Gson gson = new Gson();
        BranchBindingQuery branchBindingQuery = new BranchBindingQuery();
        branchBindingQuery.setCorpNo("corpInst1234");
        branchBindingQuery.setTrxAccDate("2017-03-15");
        branchBindingQuery.setTrxAccTime("13:30:01");
        branchBindingQuery.setCorpDate("2017-03-15");
        branchBindingQuery.setCorpSerno("ABC987654321");
        branchBindingQuery.setOutServiceCode("unbinding");
        branchBindingQuery.setMediumId("6214760200000022233");
        branchBindingQuery.setSecretKey("ASDQWEQDZCSDFAWWQDA");



        Map result = branchBindingQueryService.branchBindingQuery(branchBindingQuery);

        log.info(gson.toJson(result));

        Assert.assertEquals("0", result.get("return_code").toString());


    }

}



