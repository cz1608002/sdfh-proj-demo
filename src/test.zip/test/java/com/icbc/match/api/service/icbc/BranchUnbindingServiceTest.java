package com.icbc.match.api.service.icbc;


import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.entity.BranchUnbinding;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;


@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class BranchUnbindingServiceTest {


    @Autowired
    private BranchUnbindingService settlementAccountBranchUnbindingService;

    @Test
    public void settlementAccountBranchUnbindingV1Test() {

        Gson gson = new Gson();
        BranchUnbinding branchUnBinding = new BranchUnbinding();
        branchUnBinding.setCorpNo("corpInst1234");
        branchUnBinding.setTrxAccDate("2017-03-15");
        branchUnBinding.setTrxAccTime("13:30:01");
        branchUnBinding.setCorpDate("2017-03-15");
        branchUnBinding.setCorpSerno("ABC987654321");
        branchUnBinding.setOutServiceCode("unbinding");
        branchUnBinding.setMediumId("6214760200000022233");
        branchUnBinding.setBindMedium("6222030200000600407");
        branchUnBinding.setMobileNo("13611223388");
        branchUnBinding.setSecretKey("ASDQWEQDZCSDFAWWQDA");



        Map result = settlementAccountBranchUnbindingService.settlementAccountBranchUnbinding(branchUnBinding);

        log.info(gson.toJson(result));

        Assert.assertEquals("0", result.get("return_code").toString());


    }

}

