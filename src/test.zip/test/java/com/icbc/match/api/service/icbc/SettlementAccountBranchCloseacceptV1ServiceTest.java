package com.icbc.match.api.service.icbc;

import com.google.gson.Gson;
import com.icbc.match.YkgyjApplication;
import com.icbc.match.entity.SettlementAccountBranchCloseaccept;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = YkgyjApplication.class)
public class SettlementAccountBranchCloseacceptV1ServiceTest {

    @Autowired
    private SettlementAccountBranchCloseacceptV1Service settlementAccountBranchCloseacceptV1Service;

    @Test
    public void test() {

        Gson gson = new Gson();
        SettlementAccountBranchCloseaccept settlementAccountBranchCloseaccept = new SettlementAccountBranchCloseaccept();

        settlementAccountBranchCloseaccept.setCorpNo("corpInst1234");
        settlementAccountBranchCloseaccept.setTrxAccDate("2020-12-13");
        settlementAccountBranchCloseaccept.setTrxAccTime("13:30:01");
        settlementAccountBranchCloseaccept.setCorpDate("2020-12-13");
        settlementAccountBranchCloseaccept.setCorpSerno("ABC123456789");
        settlementAccountBranchCloseaccept.setOutServiceCode("closeaccount");
        settlementAccountBranchCloseaccept.setMediumId("");
        settlementAccountBranchCloseaccept.setSecretKey("");
        settlementAccountBranchCloseaccept.setCallType("API");


        Map result = settlementAccountBranchCloseacceptV1Service.execute(settlementAccountBranchCloseaccept);

        log.info(gson.toJson(result));

        Assert.assertEquals("0", result.get("return_code").toString());
    }
}
