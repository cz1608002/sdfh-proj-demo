package com.icbc.match.snowflake;


import com.google.gson.Gson;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;


@RunWith(SpringRunner.class)
@ContextConfiguration(classes = SnowflakeIdService.class)
public class SnowflakeIdWokerTest {

    private static final Logger logger = LoggerFactory.getLogger(SnowflakeIdWokerTest.class);

    @Autowired
    private SnowflakeIdService idService;

    /**
     * 测试用例-测试雪花算法生成
     * 连续生成10000个，是否为递增
     */
    @Test
    public void testIdGenerate() {
    }



}
